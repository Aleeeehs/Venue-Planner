<?php

    $hostName = "rsp3635.000webhostapp.com";
    $username = "id5646369_eventapplogin";
    $password = "password";
    $dbname = "registerUser";

    $con = mysqli_connect($hostName, $username, $password, $dbname);

        
   /*
    $fname = $_POST["firstName"];
    $lname = $_POST["lastName"];
    $username = $_POST["username"];
    $password = $_POST["password"];

    $statement = mysqli_prepare($con, "INSERT INTO user (fname, lname, username, password) VALUES (?, ?, ?, ?)");
    mysqli_stmt_bind_param($statement, "siss", $name, $username, $age, $password);
    mysqli_stmt_execute($statement);
    
    $response = array();
    $response["success"] = true;  
    
    echo json_encode($response);
*/
?>
