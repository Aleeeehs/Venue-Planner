package com.example.charlie.eventapp;

import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class RegisterRequest extends StringRequest {

    private static final String Request_url = "rsp3635.000webhostapp.com/public_html/Register.php";

    private Map<String, String> Params;

    public RegisterRequest(String nameFirst, String nameLast, String Username, String Password, Response.Listener<String> Listener) {
        super(Method.POST, Request_url, Listener, null);

        Params = new HashMap<>();
        Params.put("first name", nameFirst);
        Params.put("last name", nameLast);
        Params.put("username", Username);
        Params.put("password", Password);
    }

    @Override
    public Map<String, String> getParams() {
        return Params;
    }
}
