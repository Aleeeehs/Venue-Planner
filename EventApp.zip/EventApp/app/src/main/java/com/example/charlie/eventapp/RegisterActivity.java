package com.example.charlie.eventapp;

import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class RegisterActivity extends AppCompatActivity {

    private EditText nameFirst;
    private EditText nameLast;
    private EditText nameUser;
    private EditText passwordFirst;
    private EditText passwordSecond;
    private RelativeLayout Register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        nameFirst = (EditText)findViewById(R.id.etFirst);
        nameLast = (EditText)findViewById(R.id.etLast);
        nameUser = (EditText)findViewById(R.id.etUsername);
        passwordFirst = (EditText)findViewById(R.id.etPassword);
        passwordSecond = (EditText)findViewById(R.id.etRepassword);
        Register = (RelativeLayout)findViewById(R.id.rlRegister);

        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String firstName = nameFirst.getText().toString();
                final String lastName = nameLast.getText().toString();
                final String Username = nameUser.getText().toString();
                final String Password = passwordFirst.getText().toString();

                Response.Listener<String> respondListen = new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                    try{
                        JSONObject jResponce = new JSONObject(response);
                        boolean success = jResponce.getBoolean("success");

                        if(success){
                            Intent intentLogin = new Intent(RegisterActivity.this, MainActivity.class);
                            startActivity(intentLogin);
                        }
                        else{
                            AlertDialog.Builder builder = new AlertDialog.Builder(RegisterActivity.this);
                            builder.setMessage("Register has failed").setNegativeButton("Retry", null).create().show();

                        }
                    }
                    catch (JSONException e){
                        e.printStackTrace();
                    }

                    }
                };

                RegisterRequest rRequest = new RegisterRequest(firstName, lastName, Username, Password, respondListen);
                RequestQueue rQueue = Volley.newRequestQueue(RegisterActivity.this);
                rQueue.add(rRequest);

            }
        });
    }
}
