package com.example.charlie.eventapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText userName;

    private EditText passCode;
    private RelativeLayout login;+
    private TextView register;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        userName = (EditText)findViewById(R.id.etUser);
        passCode = (EditText)findViewById(R.id.etPasscode);
        login = (RelativeLayout)findViewById(R.id.rlLogin);
        register = (TextView)findViewById(R.id.tvRego);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Validate(userName.getText().toString(), passCode.getText().toString());
            }
        });

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)   {
                Intent intentRego = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(intentRego);
            }
        });
    }

    private void Validate(String userName, String passCode) {
        if((userName.equals("admin") && (passCode.equals("1234")))) {
            Intent intentMenu = new Intent(MainActivity.this, MenuActivity.class);
            startActivity(intentMenu);
        }
    }
}
